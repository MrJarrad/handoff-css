---
schema: design-handoff
schemaVersion: 17
contract: layer-brief/1
lane: selection/design
generatedAt: "2026-11-08T14:34:28.314Z"
exportVersion: 1
documentName: "JHD-Spec-DesignSystem"
pageName: "Block"
figma:
  pageCount: 17
policies:
  fingerprint: 1
  naming: 3
  units: 5
  mode: 3
  responsive: 1
  typeRamp: 1
  contentHash: 1
fingerprint:
  designSystemStateHash: "3e56da82e2ce4a5037a22f91eab783edfbdcf27041eaa92516067d90f8ecc95b"
companion:
  artifactFilename: "jhd-spec-designsystem-design-system-handoff"
  schema: "design-system-handoff"
  schemaVersion: 19
  contentHash: "015efbfd7e31b6a86e74b78b0e7e8fe811bfe01dad163be8c0887345afea00e6"
  designSystemStateHash: "3e56da82e2ce4a5037a22f91eab783edfbdcf27041eaa92516067d90f8ecc95b"
  stale: false
breakpoints:
  - family: lg
    layoutVariant: default
    widthPx: 1280
  - family: sm
    layoutVariant: default
    widthPx: 375
  - family: md
    layoutVariant: default
    widthPx: 768
  - family: xl
    layoutVariant: default
    widthPx: 1920
  - family: lg
    layoutVariant: flush
    widthPx: 1280
  - family: sm
    layoutVariant: flush
    widthPx: 375
  - family: md
    layoutVariant: flush
    widthPx: 768
  - family: xl
    layoutVariant: flush
    widthPx: 1920
  - family: lg
    layoutVariant: sidebar-main
    widthPx: 1280
  - family: lg
    layoutVariant: sidebar-main-flush
    widthPx: 1280
selectedNodes:
  - id: "611:11820"
    name: "Media"
contentHash: "1cd49a8aa39ed94451dbc7155c37697f1f7028a769e548d1dee81b57cdb69f85"
---

## Design handoff

**Artifact:** `design-handoff` schema v17 · compatibility `layer-brief/1` · lane `selection/design` · filename `design-handoff-jhd-spec-designsystem-block-media.md`
**Content hash:** `1cd49a8aa39ed94451dbc7155c37697f1f7028a769e548d1dee81b57cdb69f85` · SHA-256 · policy v1 · canonical structured payload excludes generation metadata and changelog state


**Fingerprint:** current design-system state `3e56da82e2ce4a5037a22f91eab783edfbdcf27041eaa92516067d90f8ecc95b` · SHA-256 policy v1 · naming v3 · units v5 · mode v3 · responsive v1

**File:** [JHD-Spec-DesignSystem](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0) · 17 pages · **Page:** [Block](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=23-6)

_Generated: 2026-11-08 14:34:28 UTC_

**Legend:** `$name` = variable · `⚠raw value` = unbound raw value · `⚠ placeholder` = placeholder copy · `†` = table note (token-swap, variant-only, row-wrap) · `◆instance of` = component instance (with #nodeId of source) · `props()` = component property values (`*` = overridden from default) · `#id` = node ID for Plugin API · `⊹absolute` = absolute positioned · `constraints()` = pinning (when not in auto-layout) · `col(S/N of M)` = grid-column: S / span N on M-col grid · `row(S/N)` = grid-row: S / span N · `aspect: $token (stable)` = same aspect-ratio across all breakpoints → use CSS `aspect-ratio`; `$token` references an aspect variable when available · `aspect: varies ($t1→$t2)` = ratio shifts across breakpoints → implement per-breakpoint dimensions · `justify:X` / `align:X` = flex/grid alignment · `scrollX` / `scrollY` / `scrollXY` = overflow scroll direction · `text-align:X` = text-align · `case:X` = text-transform · `decoration:X` = text-decoration · `decoration:X(style:… thickness:… offset:… skipInk:… color:…)` = full underline/strikethrough config — thickness/offset percentages are of font size (10% → 0.1em); percentages are the operator-authored contract, not token-bound · `truncate(N lines)` = text-overflow: ellipsis with max lines · `link(url)` = hyperlink destination · `🎭mask(type)` = clipping mask (clip-path / alpha-mask / luminance-mask) · `⚠mixed-styles` = text node with mixed inline formatting (needs `<span>` sub-ranges) · `👁hidden` = not visible · `🖼` = image fill (with scaleMode) · `🎬` = video fill · `📝` = annotation · `spacer(edge:start|edge:end|edge:both|mid)` = Spacer position among visible siblings · `🎞` = animation style · `⏱` = keyframe track · `[→]` = node link · `semantic(<tag>)` = authored HTML element (designer wrote `semantic(<tag>)` in description) · `~semantic(<tag>)` = inferred HTML element (from naming, structure, or interactions) · `⚠semantic-invalid(reason)` = authored directive with invalid nesting · `~semantic-rejected(<tag>; reason)` = rejected inference; do not use that tag · `states(:hover, :focus, …)` = CSS pseudo-class states available as component variants · `interactive(click, hover)` = node has prototype interactions → needs interactive HTML element · `position(sticky)` / `position(fixed)` = positioning hint from description · `@container` = container query hint from description · `a11y(…)` = accessibility attribute from description (aria-*, role) · `desc("…")` = designer description note

**How to use this brief:**
1. **Screenshots are visual ground truth** — match them before consulting the layer tree
2. **Understand frame groups** — full-page frames contain the complete design; viewport-state frames show scroll positions for reference only
3. **Use components, don't rebuild them** — instantiate from the component index by name with the right props
**Warning:** 1 token binding validation finding(s); see `validation.findings` in JSON.

4. **Follow variable bindings** — use `$token` values, never hardcode a matching raw value; `⚠raw` flags values that should be bound; `⚠ placeholder` flags placeholder copy
5. **Recreate top-down** — frame → auto-layout sections → component instances → details
6. **Ignore** — viewport state frames (reference only), `👁hidden` layers, computed fill/hug dimensions
7. **Cite by node ID** — use `#id` references (stable across exports), not line numbers (which drift)
8. **Responsive implementation** — pixel dimensions are reference only; implement using grid placement (`col(start/span of total)`), flex/fill sizing, and aspect ratios. When the grid table Notes column shows `aspect: R (stable)`, use `aspect-ratio: R` in CSS and let height be intrinsic. When it shows `aspect: varies`, set explicit dimensions per breakpoint instead. The Variable Tokens section shows how values change across modes
9. **Semantic HTML** — `semantic(<tag>)` is an authored directive (designer-specified in description); `~semantic(<tag>)` is an inferred hint (from naming or structure — treat as guidance, not requirement). When `~semantic(<ul>)` is inferred, its children carry `~semantic(<li>)`. Use `interactive()` to identify elements that need event handling; use `states()` to implement CSS pseudo-class variants
10. **Accessibility** — honour `a11y()` attributes from designer descriptions; use `semantic()` and `~semantic()` tags for correct ARIA roles; interactive elements without `semantic(<button>)` or `semantic(<a>)` still need `role` and keyboard handling
11. **Description conventions** — `position(sticky/fixed)` and `@container` hints come from designer descriptions and should be implemented directly; `desc()` is a designer note for build context

**Design system handoff:**
- Last-known companion `jhd-spec-designsystem-design-system-handoff` · `design-system-handoff` v19 · content `015efbfd7e31b6a86e74b78b0e7e8fe811bfe01dad163be8c0887345afea00e6` · state `3e56da82e2ce4a5037a22f91eab783edfbdcf27041eaa92516067d90f8ecc95b`
- Policies: fingerprint v1 · naming v3 · units v6 · mode v3 · 10 collections · 660 variables · 112 styles
- Generated: 2026-10-29T22:03:13.676Z · independent state hash ✓ matches.
- Hash references identify the last-known companion only; they do not claim simultaneous export.

**Breakpoints:** lg/default=1280px · sm/default=375px · md/default=768px · xl/default=1920px · lg/flush=1280px · sm/flush=375px · md/flush=768px · xl/flush=1920px · lg/sidebar-main=1280px · lg/sidebar-main-flush=1280px

**Themes:** light (`8:3`) · dark (`26:0`) · bttf (`4701:1`)

**Build standards:**
1. **Repeated property combinations become a class** — when the same combination of properties appears on more than one node, implement it as one named class/utility applied by name, never re-declared per surface or inlined. Inline `style=` only for truly per-instance computed values. Name the role (`.blend-ink`), not the properties.
2. **Semantic structure** — use elements that describe what content *is*, not how it looks. Navigation is `<nav>`, a list of items is `<ul>`/`<ol>`, a page region is a landmark (`<header>`, `<main>`, `<footer>`, `<aside>`). Heading levels follow document outline, not visual size.
3. **Token-first values** — every `$token` in this brief must resolve to a variable/token in code (CSS custom property, Tailwind theme value, or equivalent), never a hardcoded literal that happens to match. If the design says `$spacing/lg`, code says `var(--spacing-lg)` or the framework equivalent — not `24px`.
4. **Component boundaries match the design** — if this brief shows a `◆instance of`, it is a component in code with the same name, same props, same boundary. Do not flatten instances into inline markup or split one instance across multiple components.
5. **Grid frames are CSS Grid containers** — a `[Grid]` frame is a CSS `display: grid` container in code; children are placed by `grid-column: start / span N`, never by widths computed from column maths. `col(S/N of M)` maps to `grid-column: S / span N` on an M-column grid. When `row()` is present, also set `grid-row`.

**Changelog:** _No prior export for this subject._

**Screenshots (1):**

![Media / layout=default](data:image/png;base64,)

---

## Design Summary

### Component Properties

Every property the Figma properties panel shows, nested exposed instances included, as the block ships it. Build class (Props by default) and CMS follow-through are proposed from the property, not decided: an open one is an ask in the link-run notes, and a build takes the proposal until it is answered.

| Owner | Node | Property | Type | Value | Component default | Options | Source | Build class | Follows to CMS |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Media | #611:11820 | has-spacer-top | BOOLEAN | true | true | — | own | build prop (open) | yes (open) |
| Media | #611:11820 | has-spacer-bottom | BOOLEAN | true | true | — | own | build prop (open) | yes (open) |
| Media | #611:11820 | layout | VARIANT | `default` | `default` | `default` | own | build prop (open) | yes (open) |
| Media › SpacerTop | #611:12589 | layout | VARIANT | `space` | `space` | `space`, `screen` | exposed | build prop | no |
| Media › SpacerTop | #611:12589 | size | VARIANT | `300` | `300` | `300`, `100`, `200`, `400`, `500`, `600`, `full`, `700` | exposed | build prop | no |
| Media › Media | #656:3057 | has-video-controls | BOOLEAN | true | true | — | exposed | build prop (open) | yes (open) |
| Media › Media | #656:3057 | has-overlay | BOOLEAN | false | false | — | exposed | build prop (open) | yes (open) |
| Media › Media | #656:3057 | ratio | VARIANT | `landscape` | `laptop` | `landscape`, `square`, `portrait`, `tall`, `laptop`, `phone` | exposed | build prop (open) | yes (open) |
| Media › Media › .ControlMedia | #I656:3057;5217:35484 | has-video | BOOLEAN | true | true | — | exposed | build prop (open) | yes (open) |
| Media › Media › .ControlMedia | #I656:3057;5217:35484 | has-audio | BOOLEAN | true | true | — | exposed | build prop (open) | yes (open) |
| Media › Media › .ControlMedia | #I656:3057;5217:35484 | state | VARIANT | `activated` | `activated` | `activated`, `muted`, `paused`, `muted-paused` | exposed | state | no |
| Media › SpacerBottom | #611:12598 | layout | VARIANT | `space` | `space` | `space`, `screen` | exposed | build prop | no |
| Media › SpacerBottom | #611:12598 | size | VARIANT | `300` | `300` | `300`, `100`, `200`, `400`, `500`, `600`, `full`, `700` | exposed | build prop | no |

### Content Outline
_From Media:_

- **layout=default:** 1 image
  - **SpacerTop**
  - **content:** 1 image
  - **SpacerBottom**

### Spacing Scale
_5 unique values:_ 2, 16, 20, 48, 400

### Prototype Flows

- **ActionButtonIcon** mouse-enter → change-to → "style=primary, size=100, state=hovered" `smart-animate 750ms cubic-bezier(0.85, 0, 0.15, 1)` [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35484;1195:12347)
- **ActionButtonIcon** mouse-enter → change-to → "style=primary, size=100, state=hovered" `smart-animate 750ms cubic-bezier(0.85, 0, 0.15, 1)` [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35484;1195:12445)

### Motion & Transition Tokens

**Durations:**
- `$duration/0` = 0 → `0ms`
- `$duration/50` = 0.05000000074505806 → `50ms`
- `$duration/100` = 0.10000000149011612 → `100ms`
- `$duration/200` = 0.20000000298023224 → `200ms`
- `$duration/250` = 0.25 → `250ms`
- `$duration/300` = 0.30000001192092896 → `300ms`
- `$duration/375` = 0.375 → `375ms`
- `$duration/400` = 0.4000000059604645 → `400ms`
- `$duration/500` = 0.5 → `500ms`
- `$duration/600` = 0.6000000238418579 → `600ms`
- `$duration/700` = 0.699999988079071 → `700ms`
- `$duration/750` = 0.75 → `750ms`
- `$duration/800` = 0.800000011920929 → `800ms`
- `$duration/900` = 0.8999999761581421 → `900ms`
- `$duration/1000` = 1 → `1000ms`
- `$duration/1100` = 1.100000023841858 → `1100ms`
- `$duration/1200` = 1.2000000476837158 → `1200ms`
- `$duration/1300` = 1.2999999523162842 → `1300ms`
- `$duration/1400` = 1.399999976158142 → `1400ms`
- `$duration/1500` = 1.5 → `1500ms`
- `$duration/1600` = 1.600000023841858 → `1600ms`
- `$duration/1700` = 1.7000000476837158 → `1700ms`
- `$duration/1800` = 1.7999999523162842 → `1800ms`
- `$duration/1900` = 1.899999976158142 → `1900ms`
- `$duration/2000` = 2 → `2000ms`

**Components used (6):**
- [Spacer](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=30-159) #30:159 — 2 instances (Media: 2)
- [ActionButtonIcon](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=326-3407) #326:3407 — 2 instances (Media: 2)
- [Media](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=5217-35474) #5217:35474 — 1 instance (Media: 1)
- [.ControlMedia](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=1195-12465) #1195:12465 — 1 instance (Media: 1)
- [SpeakerFilled200](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=321-2794) #321:2794 — 1 instance (Media: 1)
- [PlayFilled200](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=321-2758) #321:2758 — 1 instance (Media: 1)

**Variable tokens (16 unique):**
_Naming v3 preserves manual syntax and existing collection/core rules. Units v5 infers opacity/percentage scale across terminal mode values and inherits alias units. Responsive v1 treats layout gap modes as unchanged samples._
- $radius/action/action-radius-round → CSS `--radius-action-radius-round` · default=0.25rem
  scopes CORNER_RADIUS · stored raw-number / source px / build rem via divide-by-root-font-size (root 16px) (high)
  modes `[{"modeId":"8:0","modeName":"default","build":{"status":"resolved","raw":4,"value":0.25,"unit":"rem","css":"0.25rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope"}}]`
  (=4)
- $dimension/dimension-700 → CSS `--dimension-700` · default=1.25rem
  scopes WIDTH_HEIGHT, GAP, PARAGRAPH_SPACING, PARAGRAPH_INDENT, FONT_VARIATIONS · stored raw-number / source px / build rem via divide-by-root-font-size (root 16px) (high)
  modes `[{"modeId":"8:0","modeName":"default","build":{"status":"resolved","raw":20,"value":1.25,"unit":"rem","css":"1.25rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope"}}]`
  (=20)
- $dimension/button-icon-width → CSS `--dimension-button-icon-width` · 100=1.75rem · 200=2rem · 300=2.75rem
  scopes WIDTH_HEIGHT · stored raw-number / source px / build rem via divide-by-root-font-size (root 16px) (high) · alias→`dimension/dimension-900`
  modes `[{"modeId":"363:0","modeName":"100","build":{"status":"resolved","raw":28,"value":1.75,"unit":"rem","css":"1.75rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:807:4082","variableKey":"2559980b2171857e02c91f3d69c0a241b36e1d69","variableName":"dimension/dimension-900","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"804:0","modeName":"200","build":{"status":"resolved","raw":32,"value":2,"unit":"rem","css":"2rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:807:4082","variableKey":"2559980b2171857e02c91f3d69c0a241b36e1d69","variableName":"dimension/dimension-900","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"804:1","modeName":"300","build":{"status":"resolved","raw":44,"value":2.75,"unit":"rem","css":"2.75rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:807:4082","variableKey":"2559980b2171857e02c91f3d69c0a241b36e1d69","variableName":"dimension/dimension-900","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}}]`
  (=$Button/button-height/100→$dimension/dimension-900→28 @100 / $Button/button-height/200→$dimension/dimension-1000→32 @200 / $Button/button-height/300→$dimension/dimension-1150→44 @300)
- $icon-weight/primary → CSS `--icon-weight-primary` · 400=10px · 100=2px · 200=2px · 300=5px
  scopes STROKE_FLOAT · stored raw-number / source px / build px via identity (high) · alias→`border/border-1100`
  modes `[{"modeId":"315:0","modeName":"400","build":{"status":"resolved","raw":10,"value":10,"unit":"px","css":"10px","conversionStrategy":"identity","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:2539:22610","variableKey":"7120b10fe893b28edd997167255c64dff81f96cf","variableName":"border/border-1100","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"315:1","modeName":"100","build":{"status":"resolved","raw":2,"value":2,"unit":"px","css":"2px","conversionStrategy":"identity","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:2539:22610","variableKey":"7120b10fe893b28edd997167255c64dff81f96cf","variableName":"border/border-1100","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"315:2","modeName":"200","build":{"status":"resolved","raw":2,"value":2,"unit":"px","css":"2px","conversionStrategy":"identity","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:2539:22610","variableKey":"7120b10fe893b28edd997167255c64dff81f96cf","variableName":"border/border-1100","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"315:3","modeName":"300","build":{"status":"resolved","raw":5,"value":5,"unit":"px","css":"5px","conversionStrategy":"identity","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:2539:22610","variableKey":"7120b10fe893b28edd997167255c64dff81f96cf","variableName":"border/border-1100","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}}]`
  (=$border/border-1100→10 @400 / $border/border-300→2 @100 / $border/border-300→2 @200 / $border/border-900→5 @300)
- $space/spacer-300 → CSS `--space-spacer-300` · lg=3rem · sm=1.5rem · md=2rem · xl=3rem · lg-flush=3rem · sm-flush=1.5rem · md-flush=2rem · xl-flush=3rem · lg-sidebar-main=3rem · lg-sidebar-main-flush=3rem
  scopes WIDTH_HEIGHT, GAP, FONT_VARIATIONS · stored raw-number / source px / build rem via divide-by-root-font-size (root 16px) (high) · alias→`dimension/dimension-1200`
  modes `[{"modeId":"89:1","modeName":"lg","build":{"status":"resolved","raw":48,"value":3,"unit":"rem","css":"3rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"26:1","modeName":"sm","build":{"status":"resolved","raw":24,"value":1.5,"unit":"rem","css":"1.5rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"8:5","modeName":"md","build":{"status":"resolved","raw":32,"value":2,"unit":"rem","css":"2rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"81:0","modeName":"xl","build":{"status":"resolved","raw":48,"value":3,"unit":"rem","css":"3rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:1","modeName":"lg-flush","build":{"status":"resolved","raw":48,"value":3,"unit":"rem","css":"3rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:2","modeName":"sm-flush","build":{"status":"resolved","raw":24,"value":1.5,"unit":"rem","css":"1.5rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:3","modeName":"md-flush","build":{"status":"resolved","raw":32,"value":2,"unit":"rem","css":"2rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:4","modeName":"xl-flush","build":{"status":"resolved","raw":48,"value":3,"unit":"rem","css":"3rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:5","modeName":"lg-sidebar-main","build":{"status":"resolved","raw":48,"value":3,"unit":"rem","css":"3rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:6","modeName":"lg-sidebar-main-flush","build":{"status":"resolved","raw":48,"value":3,"unit":"rem","css":"3rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}}]`
  (=$dimension/dimension-1200→48 @lg / $dimension/dimension-800→24 @sm / $dimension/dimension-1000→32 @md / $dimension/dimension-1200→48 @xl / $dimension/dimension-1200→48 @lg-flush / $dimension/dimension-800→24 @sm-flush / $dimension/dimension-1000→32 @md-flush / $dimension/dimension-1200→48 @xl-flush / $dimension/dimension-1200→48 @lg-sidebar-main / $dimension/dimension-1200→48 @lg-sidebar-main-flush)
  Responsive behavior: default=mode-stepped; flush=mode-stepped; sidebar-main=3rem; sidebar-main-flush=3rem
- $device/width → CSS `--device-width` · lg=1280px · sm=375px · md=768px · xl=1920px · lg-flush=1280px · sm-flush=375px · md-flush=768px · xl-flush=1920px · lg-sidebar-main=1280px · lg-sidebar-main-flush=1280px
  scopes WIDTH_HEIGHT · stored raw-number / source px / build px via identity (high) · 📝 100% of screen width
  modes `[{"modeId":"89:1","modeName":"lg","build":{"status":"resolved","raw":1280,"value":1280,"unit":"px","css":"1280px","conversionStrategy":"identity","confidence":"high","source":"name"}},{"modeId":"26:1","modeName":"sm","build":{"status":"resolved","raw":375,"value":375,"unit":"px","css":"375px","conversionStrategy":"identity","confidence":"high","source":"name"}},{"modeId":"8:5","modeName":"md","build":{"status":"resolved","raw":768,"value":768,"unit":"px","css":"768px","conversionStrategy":"identity","confidence":"high","source":"name"}},{"modeId":"81:0","modeName":"xl","build":{"status":"resolved","raw":1920,"value":1920,"unit":"px","css":"1920px","conversionStrategy":"identity","confidence":"high","source":"name"}},{"modeId":"2813:1","modeName":"lg-flush","build":{"status":"resolved","raw":1280,"value":1280,"unit":"px","css":"1280px","conversionStrategy":"identity","confidence":"high","source":"name"}},{"modeId":"2813:2","modeName":"sm-flush","build":{"status":"resolved","raw":375,"value":375,"unit":"px","css":"375px","conversionStrategy":"identity","confidence":"high","source":"name"}},{"modeId":"2813:3","modeName":"md-flush","build":{"status":"resolved","raw":768,"value":768,"unit":"px","css":"768px","conversionStrategy":"identity","confidence":"high","source":"name"}},{"modeId":"2813:4","modeName":"xl-flush","build":{"status":"resolved","raw":1920,"value":1920,"unit":"px","css":"1920px","conversionStrategy":"identity","confidence":"high","source":"name"}},{"modeId":"2813:5","modeName":"lg-sidebar-main","build":{"status":"resolved","raw":1280,"value":1280,"unit":"px","css":"1280px","conversionStrategy":"identity","confidence":"high","source":"name"}},{"modeId":"2813:6","modeName":"lg-sidebar-main-flush","build":{"status":"resolved","raw":1280,"value":1280,"unit":"px","css":"1280px","conversionStrategy":"identity","confidence":"high","source":"name"}}]`
  (=1280 @lg / 375 @sm / 768 @md / 1920 @xl / 1280 @lg-flush / 375 @sm-flush / 768 @md-flush / 1920 @xl-flush / 1280 @lg-sidebar-main / 1280 @lg-sidebar-main-flush)
  Responsive behavior: default=100vw; flush=100vw; sidebar-main=80rem; sidebar-main-flush=80rem
- $grid/margin-default → CSS `--grid-margin-default` · lg=3rem · sm=1.5rem · md=2rem · xl=3rem · lg-flush=0rem · sm-flush=0rem · md-flush=0rem · xl-flush=0rem · lg-sidebar-main=3rem · lg-sidebar-main-flush=0rem
  scopes GAP, PARAGRAPH_SPACING, PARAGRAPH_INDENT · stored raw-number / source px / build rem via divide-by-root-font-size (root 16px) (high) · alias→`dimension/dimension-1200`
  modes `[{"modeId":"89:1","modeName":"lg","build":{"status":"resolved","raw":48,"value":3,"unit":"rem","css":"3rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"26:1","modeName":"sm","build":{"status":"resolved","raw":24,"value":1.5,"unit":"rem","css":"1.5rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"8:5","modeName":"md","build":{"status":"resolved","raw":32,"value":2,"unit":"rem","css":"2rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"81:0","modeName":"xl","build":{"status":"resolved","raw":48,"value":3,"unit":"rem","css":"3rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:1","modeName":"lg-flush","build":{"status":"resolved","raw":0,"value":0,"unit":"rem","css":"0rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:2","modeName":"sm-flush","build":{"status":"resolved","raw":0,"value":0,"unit":"rem","css":"0rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:3","modeName":"md-flush","build":{"status":"resolved","raw":0,"value":0,"unit":"rem","css":"0rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:4","modeName":"xl-flush","build":{"status":"resolved","raw":0,"value":0,"unit":"rem","css":"0rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:5","modeName":"lg-sidebar-main","build":{"status":"resolved","raw":48,"value":3,"unit":"rem","css":"3rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"2813:6","modeName":"lg-sidebar-main-flush","build":{"status":"resolved","raw":0,"value":0,"unit":"rem","css":"0rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:168","variableKey":"62db961cd4b23575032230baff0835ba9d60404a","variableName":"dimension/dimension-1200","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}}]`
  (=$dimension/dimension-1200→48 @lg / $dimension/dimension-800→24 @sm / $dimension/dimension-1000→32 @md / $dimension/dimension-1200→48 @xl / $dimension/dimension-0→0 @lg-flush / $dimension/dimension-0→0 @sm-flush / $dimension/dimension-0→0 @md-flush / $dimension/dimension-0→0 @xl-flush / $dimension/dimension-1200→48 @lg-sidebar-main / $dimension/dimension-0→0 @lg-sidebar-main-flush)
  Responsive behavior: default=mode-stepped; flush=0rem; sidebar-main=3rem; sidebar-main-flush=0rem
- $icon-dimension/width → CSS `--icon-dimension-width` · 400=5rem · 100=1rem · 200=1.25rem · 300=3rem
  scopes WIDTH_HEIGHT · stored raw-number / source px / build rem via divide-by-root-font-size (root 16px) (high) · alias→`dimension/dimension-1600`
  modes `[{"modeId":"315:0","modeName":"400","build":{"status":"resolved","raw":80,"value":5,"unit":"rem","css":"5rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:173","variableKey":"3b627936ed519ca5472f28bb9dd7ba94eead498b","variableName":"dimension/dimension-1600","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"315:1","modeName":"100","build":{"status":"resolved","raw":16,"value":1,"unit":"rem","css":"1rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:173","variableKey":"3b627936ed519ca5472f28bb9dd7ba94eead498b","variableName":"dimension/dimension-1600","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"315:2","modeName":"200","build":{"status":"resolved","raw":20,"value":1.25,"unit":"rem","css":"1.25rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:173","variableKey":"3b627936ed519ca5472f28bb9dd7ba94eead498b","variableName":"dimension/dimension-1600","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"315:3","modeName":"300","build":{"status":"resolved","raw":48,"value":3,"unit":"rem","css":"3rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:173","variableKey":"3b627936ed519ca5472f28bb9dd7ba94eead498b","variableName":"dimension/dimension-1600","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}}]`
  (=$dimension/dimension-1600→80 @400 / $dimension/dimension-600→16 @100 / $dimension/dimension-700→20 @200 / $dimension/dimension-1200→48 @300)
- $icon-dimension/height → CSS `--icon-dimension-height` · 400=5rem · 100=1rem · 200=1.25rem · 300=3rem
  scopes WIDTH_HEIGHT · stored raw-number / source px / build rem via divide-by-root-font-size (root 16px) (high) · alias→`dimension/dimension-1600`
  modes `[{"modeId":"315:0","modeName":"400","build":{"status":"resolved","raw":80,"value":5,"unit":"rem","css":"5rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:173","variableKey":"3b627936ed519ca5472f28bb9dd7ba94eead498b","variableName":"dimension/dimension-1600","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"315:1","modeName":"100","build":{"status":"resolved","raw":16,"value":1,"unit":"rem","css":"1rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:173","variableKey":"3b627936ed519ca5472f28bb9dd7ba94eead498b","variableName":"dimension/dimension-1600","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"315:2","modeName":"200","build":{"status":"resolved","raw":20,"value":1.25,"unit":"rem","css":"1.25rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:173","variableKey":"3b627936ed519ca5472f28bb9dd7ba94eead498b","variableName":"dimension/dimension-1600","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}},{"modeId":"315:3","modeName":"300","build":{"status":"resolved","raw":48,"value":3,"unit":"rem","css":"3rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope","inheritedFrom":{"variableId":"VariableID:8:173","variableKey":"3b627936ed519ca5472f28bb9dd7ba94eead498b","variableName":"dimension/dimension-1600","collectionId":"VariableCollectionId:8:80","collectionKey":"a31ee92ea81597650efeeadf23dfecb53f195459","collectionName":"core","resolutionStatus":"resolved"}}}]`
  (=$dimension/dimension-1600→80 @400 / $dimension/dimension-600→16 @100 / $dimension/dimension-700→20 @200 / $dimension/dimension-1200→48 @300)
- $color/background/default/primary → CSS `--background-default-primary` · light=var(--color-core-white) · dark=var(--color-core-black) · bttf=var(--color-core-white)
  scopes ALL_SCOPES · build unit unresolved · alias→`color/core/white`
  modes `[{"modeId":"8:3","modeName":"light","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:8:245"},"css":"var(--color-core-white)","literal":"#FFFFFFFF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}},{"modeId":"26:0","modeName":"dark","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:8:244"},"css":"var(--color-core-black)","literal":"#000000FF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}},{"modeId":"4701:1","modeName":"bttf","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:8:245"},"css":"var(--color-core-white)","literal":"#FFFFFFFF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}}]`
  (=$color/core/white→#ffffff @light / $color/core/black→#000000 @dark / $color/core/white→#ffffff @bttf)
- $color/content/default/primary → CSS `--content-default-primary` · light=var(--color-core-black) · dark=var(--color-core-white) · bttf=var(--color-palette-malibu-600)
  scopes ALL_SCOPES · build unit unresolved · alias→`color/core/black`
  modes `[{"modeId":"8:3","modeName":"light","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:8:244"},"css":"var(--color-core-black)","literal":"#000000FF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}},{"modeId":"26:0","modeName":"dark","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:8:245"},"css":"var(--color-core-white)","literal":"#FFFFFFFF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}},{"modeId":"4701:1","modeName":"bttf","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:8:250"},"css":"var(--color-palette-malibu-600)","literal":"#2279AFFF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}}]`
  (=$color/core/black→#000000 @light / $color/core/white→#ffffff @dark / $color/palette/malibu/600→#2279af @bttf)
- $color/content/action/primary → CSS `--content-action-primary` · light=var(--color-core-black) · dark=var(--color-core-white) · bttf=var(--color-palette-malibu-600)
  scopes ALL_SCOPES · build unit unresolved · alias→`color/core/black`
  modes `[{"modeId":"8:3","modeName":"light","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:8:244"},"css":"var(--color-core-black)","literal":"#000000FF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}},{"modeId":"26:0","modeName":"dark","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:8:245"},"css":"var(--color-core-white)","literal":"#FFFFFFFF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}},{"modeId":"4701:1","modeName":"bttf","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:8:250"},"css":"var(--color-palette-malibu-600)","literal":"#2279AFFF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}}]`
  (=$color/core/black→#000000 @light / $color/core/white→#ffffff @dark / $color/palette/malibu/600→#2279af @bttf)
- $dimension/dimension-200 → CSS `--dimension-200` · default=0.125rem
  scopes WIDTH_HEIGHT, GAP, PARAGRAPH_SPACING, PARAGRAPH_INDENT, FONT_VARIATIONS · stored raw-number / source px / build rem via divide-by-root-font-size (root 16px) (high)
  modes `[{"modeId":"8:0","modeName":"default","build":{"status":"resolved","raw":2,"value":0.125,"unit":"rem","css":"0.125rem","conversionStrategy":"divide-by-root-font-size","confidence":"high","source":"scope"}}]`
  (=2)
- $color/background/action/primary → CSS `--background-action-primary` · light=rgb(from var(--color-palette-cod-grey-200) r g b / var(--opacity-600)) · dark=rgb(from var(--color-palette-cod-grey-200) r g b / var(--opacity-600)) · bttf=rgb(from var(--color-palette-lightning-yellow-100) r g b / var(--opacity-600))
  scopes ALL_SCOPES · build unit unresolved
  modes `[{"modeId":"8:3","modeName":"light","build":{"status":"resolved","raw":{"color":{"type":"VARIABLE_ALIAS","id":"VariableID:8:293"},"opacity":{"type":"VARIABLE_ALIAS","id":"VariableID:8:207"}},"css":"rgb(from var(--color-palette-cod-grey-200) r g b / var(--opacity-600))","literal":"#D1D1D199","conversionStrategy":"compose-color","sourceScale":"percent-0-100","confidence":"high","source":"expression"}},{"modeId":"26:0","modeName":"dark","build":{"status":"resolved","raw":{"color":{"type":"VARIABLE_ALIAS","id":"VariableID:8:293"},"opacity":{"type":"VARIABLE_ALIAS","id":"VariableID:8:207"}},"css":"rgb(from var(--color-palette-cod-grey-200) r g b / var(--opacity-600))","literal":"#D1D1D199","conversionStrategy":"compose-color","sourceScale":"percent-0-100","confidence":"high","source":"expression"}},{"modeId":"4701:1","modeName":"bttf","build":{"status":"resolved","raw":{"color":{"type":"VARIABLE_ALIAS","id":"VariableID:8:275"},"opacity":{"type":"VARIABLE_ALIAS","id":"VariableID:8:207"}},"css":"rgb(from var(--color-palette-lightning-yellow-100) r g b / var(--opacity-600))","literal":"#FEF4C799","conversionStrategy":"compose-color","sourceScale":"percent-0-100","confidence":"high","source":"expression"}}]`
  (=rgb(from var(--color-palette-cod-grey-200) r g b / var(--opacity-600)) @light / rgb(from var(--color-palette-cod-grey-200) r g b / var(--opacity-600)) @dark / rgb(from var(--color-palette-lightning-yellow-100) r g b / var(--opacity-600)) @bttf)
- $color/background/default/tertiary → CSS `--background-default-tertiary` · light=var(--color-palette-desert-storm-200) · dark=var(--color-palette-cod-grey-900) · bttf=var(--color-palette-desert-storm-200)
  scopes ALL_SCOPES · build unit unresolved · alias→`color/palette/desert-storm/200`
  modes `[{"modeId":"8:3","modeName":"light","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:23:270"},"css":"var(--color-palette-desert-storm-200)","literal":"#E9E2DFFF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}},{"modeId":"26:0","modeName":"dark","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:8:299"},"css":"var(--color-palette-cod-grey-900)","literal":"#383838FF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}},{"modeId":"4701:1","modeName":"bttf","build":{"status":"resolved","raw":{"type":"VARIABLE_ALIAS","id":"VariableID:23:270"},"css":"var(--color-palette-desert-storm-200)","literal":"#E9E2DFFF","conversionStrategy":"variable-reference","confidence":"high","source":"inherited"}}]`
  (=$color/palette/desert-storm/200→#e9e2df @light / $color/palette/cod-grey/900→#383838 @dark / $color/palette/desert-storm/200→#e9e2df @bttf)
- $color/background/material/inverse-thinnest → CSS `--background-material-inverse-thinnest` · light=rgb(from var(--color-core-black) r g b / var(--opacity-50)) · dark=rgb(from var(--color-core-white) r g b / var(--opacity-100)) · bttf=rgb(from var(--color-core-black) r g b / var(--opacity-50))
  scopes ALL_SCOPES · build unit unresolved
  modes `[{"modeId":"8:3","modeName":"light","build":{"status":"resolved","raw":{"color":{"type":"VARIABLE_ALIAS","id":"VariableID:8:244"},"opacity":{"type":"VARIABLE_ALIAS","id":"VariableID:4702:191371"}},"css":"rgb(from var(--color-core-black) r g b / var(--opacity-50))","literal":"#0000000D","conversionStrategy":"compose-color","sourceScale":"percent-0-100","confidence":"high","source":"expression"}},{"modeId":"26:0","modeName":"dark","build":{"status":"resolved","raw":{"color":{"type":"VARIABLE_ALIAS","id":"VariableID:8:245"},"opacity":{"type":"VARIABLE_ALIAS","id":"VariableID:8:214"}},"css":"rgb(from var(--color-core-white) r g b / var(--opacity-100))","literal":"#FFFFFF1A","conversionStrategy":"compose-color","sourceScale":"percent-0-100","confidence":"high","source":"expression"}},{"modeId":"4701:1","modeName":"bttf","build":{"status":"resolved","raw":{"color":{"type":"VARIABLE_ALIAS","id":"VariableID:8:244"},"opacity":{"type":"VARIABLE_ALIAS","id":"VariableID:4702:191371"}},"css":"rgb(from var(--color-core-black) r g b / var(--opacity-50))","literal":"#0000000D","conversionStrategy":"compose-color","sourceScale":"percent-0-100","confidence":"high","source":"expression"}}]`
  (=rgb(from var(--color-core-black) r g b / var(--opacity-50)) @light / rgb(from var(--color-core-white) r g b / var(--opacity-100)) @dark / rgb(from var(--color-core-black) r g b / var(--opacity-50)) @bttf)

### Media (COMPONENT_SET) #611:11820 hug×hug [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=611-11820) clip

- **layout=default** (COMPONENT) #611:12588 hug×hug [V, align:center, justify-content:start, align-items:center] fill($color/background/default/primary) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=611-12588)
  - **SpacerTop** (INSTANCE) #611:12589 ◆instance of [Spacer/layout=space, size=300](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=30-159) #30:159 props(layout=space, size=300) spacer(edge:start) spacing($space/spacer-300) $device/width×$space/spacer-300 fill($color/background/default/primary) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=611-12589)
  - **content** (FRAME) #611:12590 fill×hug [V, pad:0/$grid/margin-default/0/$grid/margin-default, justify:end, justify-content:end, align-items:start] [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=611-12590)
    - **Media** (INSTANCE) #656:3057 ◆instance of [Media/ratio=landscape](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=5217-35474) #5217:35474 props(has-video-controls=true, has-overlay=false, ratio=landscape) fill×792 [V, justify:center, align:center, justify-content:center, align-items:center] fill($color/background/default/tertiary) +1 fills 🖼image fill #3862c761 [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=656-3057)
      - **controls** (FRAME) #I656:3057;5217:35483 ⊹absolute bounds(-24604,-13879 98×68) hug×hug [H, pad:$dimension/dimension-700, align:center, justify-content:start, align-items:center] [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35483)
        - **.ControlMedia** (INSTANCE) #I656:3057;5217:35484 ◆instance of [.ControlMedia/state=activated](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=1195-12465) #1195:12465 props(has-video=true, has-audio=true, state=activated) hug×hug [H, gap:$dimension/dimension-200, align:center, justify-content:start, align-items:center] ~semantic(<ul>) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35484)
          - **ActionButtonIcon** (INSTANCE) #I656:3057;5217:35484;1195:12347 ◆instance of [ActionButtonIcon/style=primary, size=100, state=default](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=326-3407) #326:3407 props(*icon=321:2794, style=primary, size=100, state=default) $dimension/button-icon-width×$dimension/button-icon-width [H, justify:center, align:center, justify-content:center, align-items:center] modes(action:100) clip radius($radius/action/action-radius-round) fill($color/background/action/primary) effectStyle(effect/material-blur/800) ~semantic(<li>) interactive(hover) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35484;1195:12347)
            - **SpeakerFilled200** (INSTANCE) #I656:3057;5217:35484;1195:12347;3923:75788 ◆instance of [SpeakerFilled200](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=321-2794) #321:2794 $icon-dimension/width×$icon-dimension/height modes(icon:100) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35484;1195:12347;3923:75788)
              - **base** (VECTOR) #I656:3057;5217:35484;1195:12347;3923:75788;321:2484 constraints(scale, scale) fill($color/content/default/primary) stroke($icon-weight/primary, $color/content/action/primary) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35484;1195:12347;3923:75788;321:2484)
              - **base** (VECTOR) #I656:3057;5217:35484;1195:12347;3923:75788;321:2485 constraints(scale, scale) stroke($icon-weight/primary, $color/content/action/primary, center) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35484;1195:12347;3923:75788;321:2485)
              - **base** (VECTOR) #I656:3057;5217:35484;1195:12347;3923:75788;321:2486 constraints(scale, scale) stroke($icon-weight/primary, $color/content/default/primary, center) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35484;1195:12347;3923:75788;321:2486)
          - **ActionButtonIcon** (INSTANCE) #I656:3057;5217:35484;1195:12445 ◆instance of [ActionButtonIcon/style=primary, size=100, state=default](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=326-3407) #326:3407 props(*icon=321:2758, style=primary, size=100, state=default) $dimension/button-icon-width×$dimension/button-icon-width [H, justify:center, align:center, justify-content:center, align-items:center] modes(action:100) clip radius($radius/action/action-radius-round) fill($color/background/action/primary) effectStyle(effect/material-blur/800) ~semantic(<li>) interactive(hover) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35484;1195:12445)
            - **PlayFilled200** (INSTANCE) #I656:3057;5217:35484;1195:12445;3923:75788 ◆instance of [PlayFilled200](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=321-2758) #321:2758 $icon-dimension/width×$icon-dimension/height modes(icon:100) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35484;1195:12445;3923:75788)
              - **base** (VECTOR) #I656:3057;5217:35484;1195:12445;3923:75788;317:2311 constraints(scale, scale) fill($color/content/default/primary) stroke($icon-weight/primary, $color/content/action/primary) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35484;1195:12445;3923:75788;317:2311)
      - **overlay** (FRAME) #I656:3057;5217:35482 👁hidden 362×242 aspect(3:2) clip fill($color/background/material/inverse-thinnest) ~semantic(<dialog>) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=I656-3057;5217:35482)
  - **SpacerBottom** (INSTANCE) #611:12598 ◆instance of [Spacer/layout=space, size=300](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=30-159) #30:159 props(layout=space, size=300) spacer(edge:end) spacing($space/spacer-300) $device/width×$space/spacer-300 fill($color/background/default/primary) [→](https://figma.com/design/arJSACOFZmIi5rFGlxXoi0?node-id=611-12598)

## Media

Every image and video fill, with its size on screen and crop. Listed only: the files are not in this export.

- **Media** — Media › layout=default › content › Media (image, FILL, 1184×791.51) `3862c7610b5438b6720a08c1f09444e16af0df5b` #656:3057
